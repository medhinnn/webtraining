/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package et.com.inhousetraining.L11.models;

import java.util.List;

/**
 *
 * @author eyu
 */
public class Warehouse {
    
    public int warehouseID;
    public String location;
    public int currentQuantity;
    public int maxCapacity;
    public List<Section> sections;
    
}
